/*
 * Libby Bakalar
 * This program is to gain experience with a simple loop, decision processing, counters and accumulators
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class IHCCFundraiser {
	
	//Variables
	static PrintWriter pw1;														//used to write data to the subtotal.prt file
	static PrintWriter pw2;														//used to write data to the summary.prt file
	static Scanner myScanner;													//input device 
	static LocalDate today = LocalDate.now();									//holds current date, without time portion 
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");	//used to format date 
	static NumberFormat nf;														//used to format currency
	 
	//String Variables
	static String iID; 			//input student id - length of 7
	static String iGender; 		//input gender - m or f
	static String iMajor;  		//input major code - 01 through 13
	static String iDon; 		//input donation amount - length of 7 - 9999.99
	static String iRecord = "";
	
	static String oGender; 		//formatted gender
	static String oMajor; 		//formatted major
		
	static String oMDon, oFDon, oMajorTotDon, oOverallDon, oGtDon; 	//formatted m, f, major, and overall donations
	static String oInfoDon, oMInfoDon, oFInfoDon;					//formatted information donations
	static String oManDon, oMManDon, oFManDon;						//formatted manufacturing donations
	static String oTranDon, oMTranDon, oFTranDon;					//formatted transportation donations
	
	static String oMAvg, oFAvg, oOverallAvg;						//formatted m, f, and overall avgs 
	static String oInfoAvg, oMInfoAvg, oFInfoAvg;					//formatted information avgs
	static String oManAvg, oMManAvg, oFManAvg;						//formatted manufacturing avgs
	static String oTranAvg, oMTranAvg, oFTranAvg;					//formatted transportation avgs
	
	static String oMajorName1, oMajorName2, oMajorName3, oMajorName4, oMajorName5; 
	static String oMajorName6, oMajorName7, oMajorName8, oMajorName9, oMajorName10;
	static String oMajorName11, oMajorName12, oMajorName13; 
	
	//double variables	
	static double cDon, cMajorTotDon, cGtDon;	
	static double cMDon, cFDon, cOverallDon; 
	static double cInfoDon, cMInfoDon, cFInfoDon;
	static double cManDon, cMManDon, cFManDon;
	static double cTranDon, cMTranDon, cFTranDon;
	
	static double cMAvg, cFAvg, cOverallAvg; 
	static double cInfoAvg, cMInfoAvg, cFInfoAvg;
	static double cManAvg, cMManAvg, cFManAvg;
	static double cTranAvg, cMTranAvg, cFTranAvg;
	
	//int variables
	static int cMCtr=0, cFCtr=0,cMajorCtr=0, cOverallCtr=0, cGtCtr=0; 
	static int cInfoCtr=0, cManCtr=0, cTranCtr=0; 
	static int cMInfoCtr=0, cMManCtr, cMTranCtr=0;
	static int cFInfoCtr=0, cFManCtr=0, cFTranCtr=0;
	
	static int cMajor; 
	static int hMajor;
	
	//boolean variables
	static boolean eof = false;	
	

	public static void main(String[] args) {

		init();
		
		while(!eof) {
			
			if (hMajor != cMajor) {
				//call majors
				majors();
			}
			
			//call calcs							
			calcs();
			
			//call output							
			output();	
			
			//call read
			input();
		}
		//call summary to print for pw2
		summary();
		
		//call closing
		closing();	
		
		//close output files
		pw1.close();
		pw2.close();
		
		
	//bracket to end main
	}
	
	public static void init() {
		
		try {
			myScanner = new Scanner(new File("IHCCFUND.dat"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		}
		catch(FileNotFoundException e) {
			System.out.println("File Error");
			System.exit(1);			
		}
		
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US); 
		
		//set up to print to subtotal.prt
		try {
			pw1 = new PrintWriter(new File ("subtotal.prt"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		//set up to print to summary.prt
		try {
			pw2 = new PrintWriter(new File ("summary.prt"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		//call headings
		headings();
		
		//call input
		input();
		
		hMajor = cMajor; 
		
	//bracket to end init	
	}
	
	public static void input() {
		
		if(myScanner.hasNext()) {
			iRecord = myScanner.next();
			iID = iRecord.substring(0,7);
			iGender = iRecord.substring(7,8);
			iMajor = iRecord.substring(8,10);
			iDon = iRecord.substring(10,17);			
		}
		
		else 
			eof = true;
		
		switch (iMajor) {
		
			case "01": 
				cMajor = 1;
				break;
			case "02":
				cMajor = 2; 
				break;
			case "03":
				cMajor = 3;
				break;
			case "04":
				cMajor = 4;
				break;
			case "05":
				cMajor = 5;
				break;
			case "06":
				cMajor = 6;
				break;
			case "07":
				cMajor = 7;
				break;
			case "08":
				cMajor = 8;
				break;
			case "09":
				cMajor = 9;
				break;
			case "10":
				cMajor = 10;
				break;
			case "11":
				cMajor = 11;
				break;
			case "12":
				cMajor = 12;
				break;
			case "13":
				cMajor = 9;
				break;
				
		}
			
		
	//bracket to end input	
	}
	
	public static void headings() {
		//printed to pw1 - subtotal.prt
		//Headings- should include college name, report name, and date
		pw1.format("%-10s%22s%12s%22s\n\n", today.format(dtf), "", "Indian Hills", "");
		pw1.format("%22s%15s%22s\n\n", "", "Subtotal Report", "");
		pw1.format("%-7s%15s%6s%15s%33s%42s%8s\n\n", "ID", "",  "Gender", "", "Major", "", "Donation");
		
		//printed to pw2 - summary.prt 
		//Headings - should include college name, report name, and date
		pw2.format("%-10s%40s%12s%40s\n", today.format(dtf), "", "Indian Hills", "");
		pw2.format("%48s%15s%88s\n\n", "", "Summary Report", "");
		
	}
	
	public static void calcs() {
		//moving iDonation to cDonation
		cDon = Double.parseDouble(iDon);
		
		switch (iMajor) {
		case "01":
			oMajor = "COMPUTER SOFTWARE DEVELOPMENT"; 
			cInfoDon+=cDon;
			cInfoCtr+= 1;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMInfoDon+=cDon;
				cMCtr += 1; 				
				cMInfoCtr+= 1 ;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFInfoDon+=cDon;
				cFCtr +=1; 
				cFInfoCtr =+1; 
			}
			break;
			
		case "02":
			oMajor = "DIESEL POWER SYSTEMS TECHNOLOGY";
			cTranDon+=cDon;
			cTranCtr+= 1;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMTranDon+=cDon;
				cMCtr += 1; 				
				cMTranCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFTranDon+=cDon;
				cFCtr +=1; 
				cFTranCtr =+1; 
			}
			break;
			
		case "03":
			oMajor = "AUTOMOTIVE TECHNOLOGY";
			cTranDon+=cDon;
			cTranCtr+= 1;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMTranDon+=cDon;
				cMCtr += 1; 				
				cMTranCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFTranDon+=cDon;
				cFCtr +=1; 
				cFTranCtr =+1; 
			}
			break;
			
		case "04":
			oMajor = "LASER / ELECTRO-OPTICS TECHNOLOGY"; 
			cManCtr+= 1;
			cManDon+=cDon;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMManDon+=cDon;
				cMCtr += 1; 				
				cMManCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFManDon+=cDon;
				cFCtr +=1; 
				cFManCtr =+1; 
			}
			break;
			
		case "05":
			oMajor = "ROBOTICS / AUTOMATION TECHNOLOGY";
			cManDon+=cDon;
			cManCtr+= 1;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMManDon+=cDon;
				cMCtr += 1; 				
				cMManCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFManDon+=cDon;
				cFCtr +=1; 
				cFManCtr =+1; 
			}
			break;
			
		case "06":
			oMajor = "DIGITAL FORENSICS";
			cInfoDon+=cDon;
			cInfoCtr+= 1;
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMInfoDon+=cDon;
				cMCtr += 1; 				
				cMInfoCtr+= 1 ;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFInfoDon+=cDon;
				cFCtr +=1; 
				cFInfoCtr =+1; 
			}
			break;
			
		case "07":
			oMajor = "MACHINE TECHNOLOGY"; 
			cManDon+=cDon;
			cManCtr+= 1; 
			cMajorCtr += 1; 
			cMajorTotDon+= cDon; 
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMManDon+=cDon;
				cMCtr += 1; 				
				cMManCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFManDon+=cDon;
				cFCtr +=1; 
				cFManCtr =+1; 
			}
			break;	
			
		case "08":
			oMajor = "GEOSPATIAL TECHNOLOGY";
			cInfoDon+=cDon;
			cInfoCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMInfoDon+=cDon;
				cMCtr += 1; 				
				cMInfoCtr+= 1 ;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFInfoDon+=cDon;
				cFCtr +=1; 
				cFInfoCtr =+1; 
			}
			break;
			
		case "09":
			oMajor = "ADMINISTRATIVE ASSISTANT";
			cInfoDon+=cDon;
			cInfoCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMInfoDon+=cDon;
				cMCtr += 1; 				
				cMInfoCtr+= 1 ;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFInfoDon+=cDon;
				cFCtr +=1; 
				cFInfoCtr =+1; 
			}
			break;
			
		case "10":
			oMajor = "ACCOUNTING ASSISTANT";
			cInfoDon+=cDon;
			cInfoCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMInfoDon+=cDon;
				cMCtr += 1; 				
				cMInfoCtr+= 1 ;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFInfoDon+=cDon;
				cFCtr +=1; 
				cFInfoCtr =+1; 
			}
			break;
					
		case "11":
			oMajor = "WELDING TECHNOLOGY"; 
			cManDon+=cDon;
			cManCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMManDon+=cDon;
				cMCtr += 1; 				
				cMManCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFManDon+=cDon;
				cFCtr +=1; 
				cFManCtr =+1; 
			}
			break;
			
		case "12":
			oMajor = "AUTOMOTIVE COLLISION TECHNOLOGY"; 
			cTranDon+=cDon;
			cTranCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMTranDon+=cDon;
				cMCtr += 1; 				
				cMTranCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFTranDon+=cDon;
				cFCtr +=1; 
				cFTranCtr =+1; 
			}
			break;
			
		case "13":
			oMajor = "AVAIATION PILOT TRAINING"; 
			cTranDon+=cDon;
			cTranCtr+= 1;
			cMajorCtr+=1;
			cMajorTotDon+=cDon;
			if (iGender.equals("M")) {
				oGender = "Male";
				cMDon+=cDon;
				cMTranDon+=cDon;
				cMCtr += 1; 				
				cMTranCtr+= 1;
			}
			else {
				oGender = "Female";
				cFDon+=cDon;
				cFTranDon+=cDon;
				cFCtr +=1; 
				cFTranCtr =+1; 
			}
			break;
		//bracket to end switch	
		}
				
		//calculating overalls
		cOverallCtr = cMCtr + cFCtr; 
		cOverallDon = cMDon + cFDon; 
		
		//calculating averages
		cMAvg = cMDon / cMCtr; 
		cFAvg = cFDon / cFCtr; 
		cInfoAvg = cInfoDon / cInfoCtr; 
		cManAvg = cManDon / cManCtr; 
		cTranAvg = cTranDon / cTranCtr; 
		cMInfoAvg = cMInfoDon / cMInfoCtr; 
		cFInfoAvg = cFInfoDon / cFInfoCtr; 
		cMManAvg = cMManDon / cMManCtr; 
		cFManAvg = cFManDon / cFManCtr; 
		cMTranAvg = cMTranDon / cMTranCtr; 
		cFTranAvg = cFTranDon / cFTranCtr; 
		cOverallAvg = cOverallDon / cOverallCtr; 			
		
	//bracket to end calcs	
	}	
	
	public static void output () {
		
		//formatted donations
		oMDon = nf.format(cMDon);
		oFDon = nf.format(cFDon);
		oInfoDon = nf.format(cInfoDon);
		oManDon = nf.format(cManDon);
		oTranDon = nf.format(cTranDon);
		oMInfoDon = nf.format(cMInfoDon);
		oFInfoDon = nf.format(cFInfoDon);
		oMManDon = nf.format(cMManDon);
		oFManDon = nf.format(cFManDon);
		oMTranDon = nf.format(cMTranDon);
		oFTranDon = nf.format(cFTranDon);
		oOverallDon = nf.format(cOverallDon);		
		
		//formatted averages
		oMAvg = nf.format(cMAvg);
		oFAvg = nf.format(cFAvg);
		oInfoAvg = nf.format(cInfoAvg);
		oManAvg = nf.format(cManAvg);
		oTranAvg = nf.format(cTranAvg);
		oMInfoAvg = nf.format(cMInfoAvg);
		oFInfoAvg = nf.format(cFInfoAvg);
		oMManAvg = nf.format(cMManAvg);
		oFManAvg = nf.format(cFManAvg);
		oMTranAvg = nf.format(cMTranAvg);
		oFTranAvg = nf.format(cFTranAvg);
		oOverallAvg = nf.format(cOverallAvg);
		
		
		//Detail Line - contain all input fields
		switch (iMajor) {
			case "01":
				oMajorName1 = "COMPUTER SOFTWARE DEVELOPMENT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName1, "", iDon);
				break;
			case "02":
				oMajorName2 = "DIESEL POWER SYSTEMS TECCHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName2, "", iDon);
				break;
			case "03":
				oMajorName3 = "AUTOMOTIVE TECHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName3, "", iDon);
				break;
			case "04":
				oMajorName4 = "LASER / ELECTRO-OPTICS TECHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName4, "", iDon);
				break;
			case "05":
				oMajorName5 = "ROBOTICS / AUTOMATION TECHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName5, "", iDon);
				break;
			case "06":
				oMajorName6 = "DIGITAL FORENSICS";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName6, "", iDon);
				break;
			case "07":
				oMajorName7 = "MACHINE TECHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName7, "", iDon);
				break;
			case "08":
				oMajorName8 = "GEOSPATIAL TECHNOLOGY";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName8, "", iDon);
				break;
			case "09":
				oMajorName9 = "ADMINISTRATIVE ASSISTANT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName9, "", iDon);
				break;
			case "10":
				oMajorName10 = "ADMINISTRATIVE ASSISTANT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName10, "", iDon);
				break;
			case "11":
				oMajorName11 = "ADMINISTRATIVE ASSISTANT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName11, "", iDon);
				break;
			case "12":
				oMajorName12 = "ADMINISTRATIVE ASSISTANT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName12, "", iDon);
				break;
			case "13":
				oMajorName13 = "ADMINISTRATIVE ASSISTANT";
				pw1.format("%-7s%15s%6s%15s%33s%43s%7s\n", iID, "",  oGender, "", oMajorName13, "", iDon);
				break;				
				
		}
				
		
	//bracket to end output	
	}
	
	public static void summary() {
		//summary lines - record count, amount raised, average contribution			
		//Male Summary Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Male", "", cMCtr,"", oMDon,"", oMAvg);
		
		//Female Summary Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Female","", cFCtr,"", oFDon,"", oFAvg);
				
		//Information Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Information Technology","", cInfoCtr,"", oInfoDon,"", oInfoAvg);
			
		//Manufacturing Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Manufacturing Technology","", cManCtr,"", oManDon,"", oManAvg);
				
		//Transportation Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Transportation Technology","", cTranCtr,"", oTranDon,"", oTranAvg);
				
		//Male Information Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Male Information Technology","", cMInfoCtr,"", oMInfoDon,"", oMInfoAvg);
						
		//Female Information Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Female Information Technology","", cFInfoCtr,"", oFInfoDon,"", oFInfoAvg);
				
		//Male Manufacturing Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Male Manufacturing Technology","", cMManCtr,"", oMManDon,"", oMManAvg);
								
		//Female Manufacturing Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Female Manufacturing Technology","", cFManCtr,"", oFManDon,"", oFManAvg);
				
		//Male Transportation Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Male Transportation Technology","", cMTranCtr,"", oMTranDon,"", oMTranAvg);
										
		//Female Transportation Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Female Transportation Technology","", cFTranCtr,"", oFTranDon,"", oFTranAvg);
				
		//Overall Transportation Tech Line
		pw2.format("%-35s%20s%10d%20s%15s%20s%15s\n", "Overall","", cOverallCtr,"", oOverallDon,"", oOverallAvg);
	}
	
	public static void majors() {
		
		oMajorTotDon = nf.format(cMajorTotDon);
		
		//Subtotal Line - major name, number of records for major, and subtotal of donations
		pw1.format("\n", ""); 
		pw1.format("%-6s%37s%33s%10s%10d%10s%20s\n\n", "MAJOR:","", oMajor,"", cMajorCtr,"", oMajorTotDon);		
		
		//calculating grand totals
		cGtCtr = cGtCtr + cMajorCtr;
		cGtDon = cGtDon + cMajorTotDon; 
		
		//zeroing out majors
		cMajorCtr = 0;
		cMajorTotDon =0; 
		
		hMajor = cMajor; 
		
	//bracket to end majors	
	}
	
	public static void grandtotals() {
		//formatting grandtotal
		oGtDon = nf.format(cGtDon);
		
		//Grand total line - total number of students and total donations
		pw1.format("%-12s%68s%15s%10s%20s\n\n", "GRAND TOTALS:", "", cGtCtr,"", oGtDon);		
		
		
	//bracket to end grand totals			
	}
	
	public static void closing() {
		//call majors
		majors();
		
		//call grand totals 
		grandtotals(); 		
		
	//bracket to end closing	
	}
	
//bracket ends program
}
